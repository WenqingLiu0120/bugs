/*state_flag=0*/
#include <sys/types.h>
#include <sys/mount.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/syscall.h>

#include <dirent.h>
#include <errno.h>
#include <error.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	unsigned char v0[8192];
	unsigned char v1[8192];
	char v2[] = ".";
	char v3[] = "foo";
	char v4[] = "foo/bar";
	char v5[] = "foo/bar/hln";
	char v6[] = "foo/bar/baz";
	char v7[] = "foo/bar/æøå";
	char v8[] = "foo/bar/xattr";
	char v9[] = "foo/bar/acl";
	char v10[] = "foo/bar/sln";
	char v11[] = "foo/bar/fifo";
	char v12[] = "lost+found";
	long v13;
	char v14[] = "lost+found/IwD7X03UTyqear1P5ThQBTP2gxeRS7qi12pY0q3Rpr5Pg4omXTAivXibUK2vRqdRsRzqH0H6r";
	unsigned char v15[49];
	memcpy(v15, "\xe8\xad\x2d\x1c\xc0\x0c\xe3\x8b\x77\x2d\x1c\xa2\xd0\xcc\xa4\x95\xf2\xbf\xfe\x64\x6e\x54\x95\x0d\x59\x54\xa3\x60\xb7\x09\xd4\x21\xb6\x81\x3d\xf6\x8d\xa1\x82\x84\xce\x1e\x27\x1f\xea\x4b\xb5\x5e\x0c", 49);
	char v16[] = "system.posix_acl_default";
	char v17[] = "./nUTxJlKPLC57EbnYDt0FYrED4M9IyunjOGggz05JAAONlBvz2tCYiQlkkv3jnqSB47r35wME5ibotWnuNzS5OCq87tpuhG3lNtoQn9esrFhjjSb4Q18mDwuKpiCWyEFJ51jqAMh0bMhJoINCJTwXPrpCX0gVCvmHxV75ro5RAmix237KX4p";
	char v18[] = "system.posix_acl_default";
	char v19[] = "foo/bar/ojf3g89l0vrP4b7zeA4wf8lczNjN0WEmFrov0xhyqWNu5SthaydG4Oq2mXNk3cUJTICTDrP4LkyRCq6nmk1q6pqqMEaPq3gHJtjXi8Z4tVT3LZo7HpwOemC0ylOoo447vnccvBemh7q0ee6uU2G6mS5jDTX1Vb7RMj1Itf4akuaOXeI1eW5RzAACbfC7FHWb0XrtCuRwm0IJe";
	char v20[] = "foo/F8TPFgglGeG7WQzxKmvc5a9OrFkZHGNUOqtbXXKlCasi0sdIcZvh743yHlVZ0s3OgvyBSIwetnKrdwAFT3wa5yWNh1uhrv6Vq2fJKbvBOE31ABEdC9BH7hcmgWUVQYyGadXuDR6bf7bnGnOSwZh3EKosoINEqJVQx0IARMj4RIph6D72kp4w7sov898yTbMObeY1zF3QYt6c4Dep0gl7WY1eh9a8";
	unsigned char v21[28];
	memcpy(v21, "\xa7\x7e\xd0\x4f\xe1\x67\x47\x8c\x60\x6f\x76\x2d\x7f\x71\x19\x22\x06\x4f\xe4\xb3\xb7\xa0\x0e\x46\x5b\x20\x8f\xf2", 28);
	char v22[] = "system.sockprotoname";
	char v23[] = "lost+found/lsSDJInAc0RVwOIWOOPRWcoXf7SXBTixJA8dQwl2uBWoZoKyAjNgL9DyGdVS6DNNLVykPkmJtG8Q2SOCAksVt3S8gxam9x8UQ6Eqoz7hFF8IgUUqELJ6OlE5hopqjxI74XxsU3YjGg1w8UkNn2TBlhEST2GAzZH14DsYGQFU4FRAj9XUBydvdsL4scEp9UpDfhjt5yN7DmHwwnO5j2yLsKPkwcZ54MGj3";
	char v24[] = "lost+found/5gEUjxWiGO2g6yGd1K0H31Ed8BcJMMkS2yukuQSAmUoqQ4RRMRgNRu0Z5bqQxbqyXkiR8AcseQi2T7RpZ7D0zDX2mLSkuGiSyOt6YTwAscALkb8HiLFfXkhJ5810MhQL5HPblMjbytwgU2xAOCntwVA0bC0xtQGxhgWQ0G1w9vdcyakKlYDf1NfcXfXP3mMjQs9Q6BME";
	char v25[] = "security.ima";
	char v26[] = "./WwdEgx3ZyYlYD9KS0vBksi61XGWEueyQaafEXilVEW1PdJrdD0N3hS4EiaTcEP0mzf0VLlyXF0xsHmUUnpXUHbgzA9ZOXa9UD9zXty48wzzBmTgXGBzYlfVvn5HKdQoqYmNRiQZcPYn9zReGddoOJJH6MWOzvAoTw9ueZTEz026zTlF4O3QfLhjfC7d7GRaCa";
	char v27[] = "lost+found/37v5BtXw8bJA2wVhe8tjl0zCYCl01tu2yn89gd4pELzGHSytapdMocWMmHNn8Ho64wElZIYldV0sxymVlPrZzMwmbHXkYLoaF2JmKpYvKYmHUWnFtcnsyjeYyAIWV64j9MVRB1LWX7l1dWFW70M5jzdh9tBc0DL7ZpWjqrFOyyNZVa3caQfHPHwW8586HSDqHiX5ZkTWjp5CN9mwXRBug8QnBYtSy5HFnoL";
	long v28;
	char v29[] = "foo/bar/fifo/6j7NLbVh6OazLRbgx08WajXAAwkk7HEByLZJu200OYxh0ZNxZTR7AxHKrz5yEJACdhTXhSW50Tl026vZaLgkIv59u868PEI2tmaaE6dEXOD";
	char v30[] = "user.ToljjorewxkM93M2puc1yDDWaQ43ZD401nkjcZNWU5qd6Dfv5Fu4Q8a0Ye15p36proYTNtxryoS5z7y4Kr6kzgjVIkb6mfvdRR4oI1dEn3Jm8GpS5vA2atXqc6wMlpzAE3yW2Zlqc2akGNALJLNrCthmze8jR5tg6qC9NvxyyViCtrYAAt1Kmg5mIDVkJMOPCYWaURYQxEco38wD2vWobbaum3c3OyRaWx8yPeOKrz8u7469zcyYDWQxY21wySUVPdRmFo66nC1sE72BhyksUAp0Bqw9IRcg22QHqVObhNTuST59Rpzuymu7dpEtErXGryVhTrG8Ej2eD6lcvkUrXNy8CD1O2XetV7Ywzo4BV5qgBbH4Mlwr8szI5yg5VIwyQSuNGzYm4OQF0hJKTDBZ68s96WDan9YDcTYqQ6aSV1fTiwn9AwjE4ZL83YiqgH1GiZ66gfY9gDaM9LUHFBVJirRlN";
	char v31[] = "security.IdhYhOegXqMPONd2kb1fCFe9jvDGfkGwNxU3J8jpx6EJRpL9QKocaQkHLxV0fmw3hO4zVloSr0lGp5PFPBpxbZCuUitASnB9CF6f0u7quq4hvSuJdkGDHT5m9ywZk7guMnZKhgAaWFHQhCjIuxVBQZxXXr6Fyn9IaidFMlpty5HfF0w9xRIMyEtW5yl2jvKJbvYyhMpfR6Je4Fn1e3LdHD7NBsPulhBNdhJK38xSEG4IVrHAtdlAosVziurSc0nDh6VjES9QjEgC3xKwY57MxcJeVA658tGqxlZBDgZwuF9wCTsjXx5SYP61XC4g3KU0519IhiDaxMW8nOrKKulsHrtn2xT3Hv4KwBcdspDn9jvv6kDQfyGuo9hq48tJ3vdz5Dbx3mkAUe3aOHy1DEw1LbrPkjgncJlhWKeX6PgY3j6P04REGLDbu5yemeQOv94QTixX5b66LAWJDvVTEj38mzlWcBuXIyxjftGkSKpnTL5gEa9SHAY3AJZmSSJkOFR36gmY0bKRuP78xFYFP6GZQqLqGdZeq0gwgQSfzk6t9E17TXKsdaS1OlseORHCRv88LZnKJtBR5AYYhqPKQpKnaCRxbg72bG8untC6nNXqX3NCtmXIbp591U4c9CciQldBenHP9nGeqdriNMyyB15CV8mcIOLg9yrmj6BstPXk2OQPiOLtPP3sVpVnDoRLkI7TOGMIgr0gDO4vkNo9krzFeS2pGRA0jFS6UmM8dKoqiqjSEVZyMWCyxCnDewCL9cRdOllz5YnnMWDY1kVLHhJEt4PV0ZrABIlX4XW93JvNn6wmrP786OKxThTTHKdQaPyeuUmvmfGXjCKaZRgfqybHg4kxMMNwjJZbmJWYwm5fxPEWpuAdrjuXleU7yp1h7YItpmPlXSPUsbyfV6IMpAraoJhl7hSEDj73VWm2y9UokRREXhYNrQxejdPqIr2VY9Y4dJ4aSZMD0mRVTzsLNoz5POvhDyCm5jqh2sFSRZfPL4vp2lAPZ9UyVOdiKoUNXI4XBHzardyChr1jcB7AIZ6nxkUFYyd3FfaOxXwmAuysj0ZK9eSQEYB9GfPme0prfNFatBM34JtnJR5Q5XoH60RKfo7Hou8RGN29XMAbf2MwTSLWz9m39DOp1V6nNDEdaEk7btgGv3DMVYsSfeWppucoNgbktoMU24ZdxGsqH5Ckb3CGfi3VcfHxMriDf2ff6FH2T9skC3Sn6e1lN5ExiWv2NbG0bvff8wfb3YJFbl0fO0Qj5fgl9ZoU82Uhv7N422d5YvJ7eJm2JBlMoQ6xxsR6utlpy8r09V4fQNn2gX5yiqIWEORCGqGAj1yi8ngHIiug5hjkFmgvaySpNt1dkFmRGi7OVmdmUYQaD9IQtyMUwmJJdIvNXfnnLsAqela9H1hV8zv2xFWr1n9f520aflN0eVoIHPPYO61W3vWyA0qAlxnqzlQeXmcBHQRWnr3Bv2gxxAv6BjEwg1ldm9FHvrQBIsf3hiFaltXg3RkCAy7pzsQkzg1vXQ4nIhrxO4X7v3nwUY9cUGPU6qC5UByzb0nrico6eKDXNyTpUcRzqrRufdy9mw8MxtDdV0h7Kuefq8ULivKXkjRPKNY6KfSFYes2eZ7wRmbFs3aYws3hbT4vqb0AGSNm4DoimucBeBRWEz2Bq6qPZuJPVJYjjvWo9IUtC75oIUIVRLgHRWhyOyLsHtbyp5kwOFpYKsNaKf5myj3NDiLcghSvY3sN9cHVp717xOiI2l40V5MgmhGQMiKvmCGtmYOcdPjamPsmBuke06KkmZA6HU13eGuRmI1PgizQ8qAHkutizBSlkdp25r3k5yBrEAEssBI01SFkL8SKKv32Ws4bh8Lk4UZGen9XxRVwslgBr9T92WCYMG72MRmOvMfY7o34DY13HhE7ohGoBSKWhSY1tKOme3KmpNo2up49VGGHwX65xObcq9ehS0U43moqAds2QuBvBSB5xFAudmXSt99J9dOAOC0YnqYElj9u9Kz6X91BtWdlfm4mOQwmdwIQkocVXmNh4KncSmlLIO4v89hUZdGAXWZIKBlqv7VyRGYt3JDLhHHnQwIyYW633dLLn59iCeebvCVyTiHAzWwOREMzkQ2l4M7rPGXZtAAmMfkqLzyLUujv83srTucVEhMdysAp2LbO0JCKG9fk3MdAPVzqObMaJgCFYM4ahdxgw70CGdvIzWQM0PCM0W";
	char v32[] = "lost+found/YKABHo5MoGdP9tOfJkfgvzeRwwc2QOVzge8vQCHFQscZl1E4jsicpN4lJemj0FggrnbIxrVNj7wV68XqyGSodUXu9Hb9VIqM3Pc0G7NyDHRJNy7MCa8n2dfBvHJQX7kaWNYlSthfA8xX44rFex2hbiqWx9uUGc4lzaWQTB5dJ28N5ychvdOWJD";
	char v33[] = "./KMhaWSyYeYtfwvr19eACQ4OZKHO6C32WNj4tC0RqYJTSCJTLxbWLfuuxBG3LI";
	char v34[] = "./uZG28Es6sBirg5GNhD6sfHl1ZbIYswOnVfpbrfijoOYUUoq9zu1fBngiMyGFue0OHnx8SdpG2NjWAXf9RhoaSSImQWzJ8zfQkcWCGMRGh8kpfNz64lgUEwFcSEtaCYyw9V9NpYdUgNKLkHPn23FEzUrRhkztHwpQPwnCS";
	long v35;
	v13 = syscall(SYS_open, (long)v3, 65536, 0);
	syscall(SYS_getdents64, (long)v13, (long)v1, 4090);
	syscall(SYS_link, (long)v6, (long)v14);
	syscall(SYS_setxattr, (long)v9, (long)v16, (long)v15, 49, 1);
	syscall(SYS_rename, (long)v7, (long)v11);
	syscall(SYS_newlstat, (long)v3, (long)v1);
	syscall(SYS_readlink, (long)v4, (long)v1, 8192);
	syscall(SYS_getdents64, (long)v13, (long)v1, 2009);
	syscall(SYS_unlink, (long)v11);
	syscall(SYS_access, (long)v11, 4);
	syscall(SYS_symlink, (long)v5, (long)v17);
	syscall(SYS_removexattr, (long)v9, (long)v18);
	syscall(SYS_link, (long)v6, (long)v19);
	syscall(SYS_unlink, (long)v14);
	syscall(SYS_chmod, (long)v4, 3072);
	syscall(SYS_link, (long)v6, (long)v20);
	syscall(SYS_newlstat, (long)v11, (long)v1);
	syscall(SYS_truncate, (long)v12, 120126556);
	syscall(SYS_setxattr, (long)v5, (long)v22, (long)v21, 28, 1);
	syscall(SYS_link, (long)v19, (long)v23);
	syscall(SYS_access, (long)v6, 0);
	syscall(SYS_link, (long)v23, (long)v24);
	syscall(SYS_rename, (long)v3, (long)v11);
	syscall(SYS_newstat, (long)v23, (long)v1);
	syscall(SYS_removexattr, (long)v23, (long)v25);
	syscall(SYS_newlstat, (long)v11, (long)v1);
	syscall(SYS_rename, (long)v19, (long)v26);
	v28 = syscall(SYS_open, (long)v27, 66, 438);
	syscall(SYS_utimes, (long)v23, (long)v1);
	syscall(SYS_fdatasync, (long)v28);
	syscall(SYS_chmod, (long)v12, 3072);
	syscall(SYS_readlink, (long)v17, (long)v1, 8192);
	syscall(SYS_link, (long)v23, (long)v29);
	syscall(SYS_removexattr, (long)v20, (long)v30);
	syscall(SYS_readlink, (long)v20, (long)v1, 8192);
	syscall(SYS_getdents64, (long)v13, (long)v1, 1815);
	syscall(SYS_lseek, (long)v28, 1554, 1);
	syscall(SYS_ftruncate, (long)v28, 105289422);
	syscall(SYS_listxattr, (long)v27, (long)v1, 1413);
	syscall(SYS_removexattr, (long)v6, (long)v31);
	syscall(SYS_unlink, (long)v24);
	syscall(SYS_rename, (long)v20, (long)v32);
	syscall(SYS_fsync, (long)v28);
	syscall(SYS_rename, (long)v11, (long)v5);
	syscall(SYS_newlstat, (long)v2, (long)v1);
	syscall(SYS_access, (long)v6, 0);
	syscall(SYS_rename, (long)v12, (long)v33);
	syscall(SYS_unlink, (long)v23);
	v35 = syscall(SYS_open, (long)v34, 66, 438);
	syscall(SYS_unlink, (long)v17);

	close(v13);
	close(v28);
	close(v35);
	return 0;
}
/* Active fds: v13 v28 v35 */
/* Files
Path: .
Type: dir
Xattrs: 
Path: lost+found/YKABHo5MoGdP9tOfJkfgvzeRwwc2QOVzge8vQCHFQscZl1E4jsicpN4lJemj0FggrnbIxrVNj7wV68XqyGSodUXu9Hb9VIqM3Pc0G7NyDHRJNy7MCa8n2dfBvHJQX7kaWNYlSthfA8xX44rFex2hbiqWx9uUGc4lzaWQTB5dJ28N5ychvdOWJD
Type: file
Xattrs: 
Path: lost+found/37v5BtXw8bJA2wVhe8tjl0zCYCl01tu2yn89gd4pELzGHSytapdMocWMmHNn8Ho64wElZIYldV0sxymVlPrZzMwmbHXkYLoaF2JmKpYvKYmHUWnFtcnsyjeYyAIWV64j9MVRB1LWX7l1dWFW70M5jzdh9tBc0DL7ZpWjqrFOyyNZVa3caQfHPHwW8586HSDqHiX5ZkTWjp5CN9mwXRBug8QnBYtSy5HFnoL
Type: file
Xattrs: 
Path: ./WwdEgx3ZyYlYD9KS0vBksi61XGWEueyQaafEXilVEW1PdJrdD0N3hS4EiaTcEP0mzf0VLlyXF0xsHmUUnpXUHbgzA9ZOXa9UD9zXty48wzzBmTgXGBzYlfVvn5HKdQoqYmNRiQZcPYn9zReGddoOJJH6MWOzvAoTw9ueZTEz026zTlF4O3QfLhjfC7d7GRaCa
Type: file
Xattrs: 
Path: foo/bar/xattr
Type: file
Xattrs: 
Path: foo/bar/sln
Type: symlink
Xattrs: 
Path: foo/bar/acl
Type: file
Xattrs: 
Path: foo/bar
Type: dir
Xattrs: 
Path: foo/bar/baz
Type: file
Xattrs: 
Path: foo/bar/fifo/6j7NLbVh6OazLRbgx08WajXAAwkk7HEByLZJu200OYxh0ZNxZTR7AxHKrz5yEJACdhTXhSW50Tl026vZaLgkIv59u868PEI2tmaaE6dEXOD
Type: file
Xattrs: 
Path: foo/bar/fifo
Type: file
Xattrs: 
Path: foo/bar/hln
Type: file
Xattrs: 
name: \x73\x79\x73\x74\x65\x6d\x2e\x73\x6f\x63\x6b\x70\x72\x6f\x74\x6f\x6e\x61\x6d\x65\x00
Path: foo/bar/hln
Type: dir
Xattrs: 
Path: ./KMhaWSyYeYtfwvr19eACQ4OZKHO6C32WNj4tC0RqYJTSCJTLxbWLfuuxBG3LI
Type: dir
Xattrs: 
Path: ./uZG28Es6sBirg5GNhD6sfHl1ZbIYswOnVfpbrfijoOYUUoq9zu1fBngiMyGFue0OHnx8SdpG2NjWAXf9RhoaSSImQWzJ8zfQkcWCGMRGh8kpfNz64lgUEwFcSEtaCYyw9V9NpYdUgNKLkHPn23FEzUrRhkztHwpQPwnCS
Type: file
Xattrs: 
*/
