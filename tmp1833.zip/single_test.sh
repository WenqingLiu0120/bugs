#!/bin/bash
sudo dmesg -c
i=$2
	echo -------------------No $i start----------------------
	if sudo mount -o loop -t $1 tmp$i.img mnt; then
		if ls mnt < /dev/null; then
			sed -i '1i \#define\ SYS_newstat\ 4\n\#define\ SYS_newlstat\ 6\n' tmp$i.c
			gcc -o tmp$i tmp$i.c
			#echo ./tmp$i ./mnt
			#./tmp$i ./mnt
			if sudo cp tmp$i mnt;then
				cd mnt
				./tmp$i
				cd ..
			else
				echo ./tmp$i ./mnt
                        	./tmp$i ./mnt
			fi
		else
			echo ls mnt failed
			cd ../
			chmod 777 test_crashes
			cd test_crashes
		fi
		sudo umount mnt
	else
		echo mount failed
                cd ../
                chmod 777 test_crashes
                cd test_crashes
	fi
	sudo dmesg -c
	echo -------------------No $i end------------------------


	
